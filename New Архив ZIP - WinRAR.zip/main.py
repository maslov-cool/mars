import random
from flask import Flask, render_template, redirect, request
from flask_wtf import FlaskForm
from wtforms import StringField, BooleanField, SubmitField, FileField
from wtforms.validators import DataRequired
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
cnt = 0


class Form(FlaskForm):
    surname = StringField('Фамилия', validators=[DataRequired()])
    name = StringField('Имя', validators=[DataRequired()])
    education = StringField('Образование', validators=[DataRequired()])
    profession = StringField('Профессия', validators=[DataRequired()])
    sex = StringField('Пол', validators=[DataRequired()])
    motivation = StringField('Мотивация', validators=[DataRequired()])
    remember_me = BooleanField('Готовы остаться на Марсе?')
    submit = SubmitField('Войти')


class Form1(FlaskForm):
    id1 = StringField('Id астронавта', validators=[DataRequired()])
    password1 = StringField('Пароль астронавта', validators=[DataRequired()])
    id2 = StringField('Id капитана', validators=[DataRequired()])
    password2 = StringField('Пароль капитана', validators=[DataRequired()])
    submit = SubmitField('Доступ')


class Form2(FlaskForm):
    file = FileField('Выберите файл', validators=[DataRequired()])
    submit = SubmitField('Отправить')


@app.route('/<string:title>')
@app.route('/index/<string:title>')
def index(title):
    return render_template('base.html', title=title)


@app.route('/training/<string:prof>')
def training(prof):
    return render_template('training.html', prof=prof)


@app.route('/list_prof/<string:type_>')
def list_prof(type_):
    list_ = ['инженер-исследователь', 'пилот', 'строитель', 'экзобиолог', 'врач',
             'инженер по терраформированию', 'климатолог',
             'специалист по радиационной защите', 'астрогеолог', 'гляциолог',
             'инженер жизнеобеспечения', 'метеоролог', 'оператор марсохода', 'киберинженер',
             'штурман', 'пилот дронов']
    return render_template('list_prof.html', type=type_, list=list_)


@app.route('/auto_answer')
def auto_answer():
    form = Form()
    if form.validate_on_submit():
        return render_template('answer.html', title='Анкета', form=form)
    return render_template('auto_answer.html', title='Заполнение анкеты', form=form)


@app.route('/login')
def login():
    form = Form1()
    return render_template('login.html', title='Заполнение анкеты', form=form)


@app.route('/distribution')
def distribution():
    peoples = [['Ридли Скотт', 'капитан корабля'], ['Энди Уир'], ['Марк Уотни'],
               ['Венката Капур'], ['Тедди Сандерс'], ['Шон Бин']]
    return render_template('distribution.html', title='Распределение', list=peoples)


@app.route('/table/<string:sex>/<string:age>')
def table(sex, age):
    return render_template('table.html', title='Оформление каюты', sex=sex, age=age)


@app.route('/galery', methods=['GET', 'POST'])
def galery():
    global cnt
    form = Form2()
    if form.validate_on_submit() and request.method == 'POST':
        cnt += 1
        f = form.file.data
        filename = f'{cnt}.png'
        # Сохраняем в папку static/img
        save_path = os.path.join('static', 'img', filename)
        f.save(save_path)
        return redirect('/galery')  # Перенаправляем чтобы избежать повторной отправки формы
    return render_template('galery.html', title='Красная планета', form=form, cnt=cnt)


@app.route('/member')
def member():
    A = [
        ['Ридли Скотт', 'Капитан корабля, опытный командир с 20-летним стажем межпланетных миссий.',
         '/static/img/1.png'],
        ['Энди Уир', 'Ботаник-инженер, гений выращивания растений в экстремальных условиях.',
         '/static/img/2.png'],
        ['Марк Уотни', 'Инженер жизнеобеспечения, специалист по ремонту систем в аварийных ситуациях.',
         '/static/img/3.png'],
        ['Венката Капур', 'Астрогеолог, эксперт по марсианскому грунту и минеральным ресурсам.',
         '/static/img/4.png'],
        ['Тедди Сандерс', 'Специалист по радиационной защите, отвечает за безопасность экипажа.',
         '/static/img/1.png'],
        ['Шон Бин', 'Пилот марсохода, мастер экстремального вождения по сложному рельефу.',
         '/static/img/2.png']
    ]
    return render_template('member.html', title='Оформление каюты', el=A[random.randint(0, len(A) - 1)])


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
